-----------------------------------------------------------------------------------
--Aquellas usadas para insertar, modificar y eliminar un Customer, Staff y Actor.--
------------------------------------------------------------------------------------
SELECT * FROM public.actor ORDER BY actor_id ASC ;

insert into actor values(default,'Julieta','Lorca Sanchez',now()) returning *;

update actor set last_name = 'Lorca' where actor_id = 201 and first_name like '%Julieta%' and last_name like '%Lorca Sanchez%';

delete from actor where actor_id = 201 and first_name like '%Julieta%' and last_name like 'Lorca';

------------------------------------------------------------------------------------

SELECT * FROM public.staff ORDER BY staff_id ASC ;

insert into staff values
(default,'Mario','Moreno',3,'mariomoreno@gmail.com',2,true,'mariom','8cbd2337d87652sdbg457jh56erer6543212',now(),null);

update staff   set password = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'  where staff_id = 3 and username like 'mariom';

delete from staff     where staff_id = 3 and username like 'mariom';

-------------------------------------------------------------------------------------

SELECT * FROM public.customer ORDER BY customer_id ASC ;

insert into customer values
(default,2,'Pedro','Perez','pedroperez@gmail.com',15,true,now(),now(),1) returning *;

update customer set activebool = false where customer_id = 600 returning *;

delete from customer where customer_id = 600 returning *;

-------------------------------------------------------------------------------------
----Listar todas las “film” del año 2006 que contengan un (rental_rate) mayor a 4.0.
-------------------------------------------------------------------------------------

SELECT title titulo_pelicula,description descripcion FROM public.film
where release_year = 2006
and rental_rate > 4.0
ORDER BY film_id ASC

------------------------------------------------------------------------------
---Listar todas las “rental” con los datos del “customer” dado un año y mes.--
------------------------------------------------------------------------------
SELECT * FROM public.rental
where customer_id = 130
and   extract(Year from rental_date) = 2005
and   extract(Month from rental_date) = 5
ORDER BY rental_id ASC ;
------------------------------------------------------------------------------
-----
------------------------------------------------------------------------------
-----Listar Número, Fecha (payment_date) y Total (amount) de todas las “payment”.
------------------------------------------------------------------------------
SELECT payment_id as Numero_arriendo, payment_date as Fecha_arriendo, amount as Total
FROM public.payment
ORDER BY payment_id ASC 

------------------------------------------------------------------------------



-------------------------------------------------------------------------------
---------- diccionario de datos -----------------------------------------------
-------------------------------------------------------------------------------
SELECT
 isc.table_name AS nombre_de_tabla,
 isc.column_name::character varying AS nombre_de_columna,
 isc.data_type::character varying AS tipo_de_dato,
 isc.column_default::character varying AS valor_por_defecto,
 isc.character_maximum_length::integer AS largo_maximo,
   CASE
     WHEN isc.udt_name::text = 'int4'::text OR isc.udt_name::text ='bool'::text THEN isc.data_type::character varying
         ELSE isc.udt_name::character varying
     END AS nombre_udt,
 isc.ordinal_position::integer AS posicion_ordinal
FROM information_schema.columns isc
WHERE isc.table_schema::text = 'public'::text
ORDER BY isc.table_name, isc.ordinal_position;